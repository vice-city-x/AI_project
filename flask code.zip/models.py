from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class EmotionRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50))
    image_path = db.Column(db.String(200))
    predicted_emotion = db.Column(db.String(20))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)