from flask import Flask, render_template, request, redirect, url_for, session, send_from_directory
from flask_sqlalchemy import SQLAlchemy
import os
import socket
import torch
from torchvision import models, transforms
from PIL import Image
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta
from functools import wraps

# ✅ matplotlib 한글 폰트 설정 (macOS/Windows 자동 대응)
import matplotlib
matplotlib.use('Agg')

import platform
from matplotlib import font_manager as fm

if platform.system() == 'Darwin':
    font_path = '/System/Library/Fonts/Supplemental/AppleGothic.ttf'
elif platform.system() == 'Windows':
    font_path = 'C:/Windows/Fonts/malgun.ttf'
else:
    font_path = ''

if os.path.exists(font_path):
    font_name = fm.FontProperties(fname=font_path).get_name()
    matplotlib.rc('font', family=font_name)
else:
    print("⚠ 한글 폰트를 찾을 수 없습니다.")

matplotlib.rcParams['axes.unicode_minus'] = False
import matplotlib.pyplot as plt
import io
import base64
from collections import Counter
from markupsafe import Markup
import random

# ✅ 감정별 코멘트 리스트
emotion_comments = {
    '행복': [
        "오늘의 기분을 일기나 사진으로 남겨보세요.",
        "가까운 사람에게 웃음을 나눠보세요.",
        "기분 좋을 때 새로운 도전을 시작해보세요.",
        "산책하며 행복한 기분을 더 느껴보세요.",
        "좋아하는 음악을 들으며 기분을 유지해보세요.",
        "자신을 칭찬하는 시간을 가져보세요.",
        "누군가에게 감사 인사를 전해보세요.",
        "기분 좋은 일을 친구와 공유해보세요.",
        "행복했던 순간을 다시 떠올려보세요.",
        "간단한 베이킹이나 요리를 해보세요."
    ],
    '슬픔': [
        "따뜻한 차 한 잔과 함께 잠시 휴식해보세요.",
        "일기를 써서 감정을 털어보세요.",
        "편안한 음악을 들어보세요.",
        "가벼운 산책으로 기분을 환기시켜보세요.",
        "믿을 수 있는 사람과 이야기 나눠보세요.",
        "좋아하는 영화를 다시 감상해보세요.",
        "마음을 진정시키는 명상을 해보세요.",
        "포근한 담요로 몸을 감싸보세요.",
        "조용한 공간에서 혼자만의 시간을 보내보세요.",
        "따뜻한 목욕이나 샤워로 기분 전환해보세요."
    ],
    '분노': [
        "심호흡 3번, 천천히 마음을 가라앉혀보세요.",
        "물 한 잔 마시며 잠시 멈춰보세요.",
        "감정을 종이에 적어 내려보세요.",
        "조용한 장소에서 시간을 보내보세요.",
        "빠르게 걷거나 운동으로 해소해보세요.",
        "명상 앱을 틀고 잠시 집중해보세요.",
        "말 대신 글로 감정을 표현해보세요.",
        "감정을 유발한 원인을 차분히 돌아보세요.",
        "긴장을 푸는 스트레칭을 해보세요.",
        "좋아하는 음악을 틀어보세요."
    ],
    '놀람': [
        "놀라운 일이 무엇이었는지 정리해보세요.",
        "깜짝 상황을 친구와 나눠보세요.",
        "다른 사람의 반응을 들어보는 것도 좋아요.",
        "감정의 원인을 적어보며 정리해보세요.",
        "차분한 음악으로 안정감을 찾아보세요.",
        "깊은 숨을 쉬며 마음을 진정해보세요.",
        "하루 일과를 다시 정리해보세요.",
        "예상 못한 일에 긍정적으로 접근해보세요.",
        "감정을 스케치나 그림으로 표현해보세요.",
        "자신의 반응을 관찰하며 마음을 들여다보세요."
    ],
    '혐오': [
        "불쾌한 상황에서 잠시 거리를 두세요.",
        "기분을 해소할 취미 활동을 해보세요.",
        "자신에게 집중할 수 있는 공간을 찾아보세요.",
        "싫었던 감정을 글로 정리해보세요.",
        "편안한 향초나 차로 긴장을 풀어보세요.",
        "깨끗하게 정리된 공간에서 머물러보세요.",
        "긍정적인 이미지나 영상을 감상해보세요.",
        "자신을 존중하는 말을 스스로에게 해보세요.",
        "반려동물이나 식물과 시간을 보내보세요.",
        "일상에서 좋은 기억을 떠올려보세요."
    ],
    '중립': [
        "가벼운 산책으로 머리를 식혀보세요.",
        "좋아하는 책을 읽으며 여유를 느껴보세요.",
        "간단한 요가나 스트레칭을 해보세요.",
        "창밖을 바라보며 마음을 비워보세요.",
        "오늘 하루를 정리하는 시간을 가져보세요.",
        "차 한 잔 하며 나른함을 즐겨보세요.",
        "음악을 들으며 잠시 휴식해보세요.",
        "블로그나 SNS에 감정을 정리해보세요.",
        "편안한 의자에서 눈을 감고 있어보세요.",
        "자신에게 조용히 응원의 말을 해보세요."
    ],
    '불안': [
        "복식호흡으로 긴장을 완화해보세요.",
        "걷기나 스트레칭으로 몸을 움직여보세요.",
        "할 수 있는 작은 일 하나부터 해보세요.",
        "걱정되는 일을 종이에 써서 정리해보세요.",
        "명상 앱이나 ASMR을 활용해보세요.",
        "신뢰할 수 있는 사람과 대화를 나눠보세요.",
        "따뜻한 담요를 덮고 휴식을 취해보세요.",
        "불안을 분산시킬 간단한 게임을 해보세요.",
        "좋아하는 향을 맡아보세요.",
        "스스로를 다독이는 말을 해보세요."
    ],
}

def get_random_comment(emotion):
    comment_list = emotion_comments.get(emotion.strip(), ["감정을 인식할 수 없습니다."])
    return random.choice(comment_list)

socket.getfqdn = lambda name=None: "localhost"
app = Flask(__name__)
app.secret_key = 'supersecretkey'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///emotion.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
USER_FILE = 'users.txt'
ADMIN_USERS = ['gsg255648', 'wkdtmdrl12345', 'gsg25564807']
db = SQLAlchemy(app)

def get_kst_now():
    return datetime.utcnow() + timedelta(hours=9)

class EmotionRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50))
    image_path = db.Column(db.String(200))
    predicted_emotion = db.Column(db.String(20))
    timestamp = db.Column(db.DateTime, default=get_kst_now)

from flask_admin import Admin, AdminIndexView, expose
from flask_admin.contrib.sqla import ModelView
from flask_admin.menu import MenuLink

class EmotionRecordModelView(ModelView):
    column_filters = ['username', 'predicted_emotion']
    column_searchable_list = ['username', 'predicted_emotion', 'image_path']
    column_formatters = {
        'image_path': lambda v, c, m, p: Markup(
            f'<img src="/userfiles/{m.username}/{os.path.basename(m.image_path)}" width="100">'
        )
    }

class MyAdminIndexView(AdminIndexView):
    @expose('/')
    def index(self):
        if 'user' not in session or session['user'] not in ADMIN_USERS:
            return redirect(url_for('login'))
        return redirect('/admin/emotionrecord/')

admin = Admin(app, name='관리자 전용', template_mode='bootstrap3', index_view=MyAdminIndexView())
admin.add_view(EmotionRecordModelView(EmotionRecord, db.session))
admin.add_link(MenuLink(name='main', category='', url='/'))

@app.context_processor
def inject_admin_users():
    return dict(ADMIN_USERS=ADMIN_USERS)

with app.app_context():
    db.create_all()

# ✅ 모델 로딩
labels = ['행복', '슬픔', '분노', '놀람', '혐오', '중립', '불안']
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize([0.5]*3, [0.5]*3)
])
device = torch.device("cpu")
model = models.densenet121(pretrained=False)
model.classifier = torch.nn.Linear(model.classifier.in_features, len(labels))
model_path = "/Users/jangseung-gi/Desktop/flask_project/densenet121_flip.pth"
model.load_state_dict(torch.load(model_path, map_location=device))
model.eval()

def predict_emotion(image_path):
    image = Image.open(image_path).convert("RGB")
    tensor = transform(image).unsqueeze(0).to(device)
    with torch.no_grad():
        outputs = model(tensor)
        _, predicted = torch.max(outputs, 1)
    return labels[predicted.item()]

def save_result(username, image_path, predicted_emotion):
    record = EmotionRecord(
        username=username,
        image_path=image_path,
        predicted_emotion=predicted_emotion
    )
    db.session.add(record)
    db.session.commit()

def load_users():
    users = {}
    if os.path.exists(USER_FILE):
        with open(USER_FILE, 'r', encoding='utf-8') as f:
            for line in f:
                username, password = line.strip().split(',')
                users[username] = password
    return users

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        users = load_users()
        if username in users:
            return render_template('register.html', error="이미 존재하는 사용자입니다.")
        with open(USER_FILE, 'a', encoding='utf-8') as f:
            f.write(f"{username},{password}\n")
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        users = load_users()
        if username in users and users[username] == password:
            session['user'] = username
            return redirect(url_for('home'))
        else:
            return render_template('login.html', error="로그인 실패: 아이디나 비밀번호 확인")
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))

@app.route('/')
@login_required
def home():
    return render_template("index.html")

@app.route('/analyze', methods=['POST'])
@login_required
def analyze():
    file = request.files['file']
    if file:
        user = session['user']
        folder = os.path.join("user_history", user)
        os.makedirs(folder, exist_ok=True)

        filename = secure_filename(file.filename)
        filepath = os.path.join(folder, filename)
        file.save(filepath)

        emotion = predict_emotion(filepath)
        comment = get_random_comment(emotion)
        save_result(user, filepath, emotion)

        return render_template("result.html", filename=filename, emotion=emotion, comment=comment)
    return "파일이 없습니다."

@app.route('/history')
@login_required
def show_history():
    user = session['user']
    records = EmotionRecord.query.filter_by(username=user).order_by(EmotionRecord.timestamp.desc()).all()
    history_data = [
        {'filename': os.path.basename(r.image_path), 'emotion': r.predicted_emotion}
        for r in records
    ]
    return render_template("history.html", history=history_data)

@app.route('/dashboard')
@login_required
def dashboard():
    user = session['user']
    records = EmotionRecord.query.filter_by(username=user).all()
    emotions = [r.predicted_emotion for r in records]

    if not emotions:
        return render_template("dashboard.html", graph_img=None, message="예측된 감정이 없습니다.", user_id=user)

    counts = Counter(emotions)
    fig, ax = plt.subplots()
    ax.bar(counts.keys(), counts.values())
    ax.set_title(f"{user} 감정 통계")

    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    img_base64 = base64.b64encode(buf.read()).decode('utf-8')
    plt.close()

    return render_template('dashboard.html', graph_img=img_base64, message=None, user_id=user)

@app.route('/userfiles/<username>/<filename>')
def user_file(username, filename):
    return send_from_directory(os.path.join("user_history", username), filename)

@app.route('/db_check')
def db_check():
    records = EmotionRecord.query.all()
    return f"DB에 저장된 감정 예측 수: {len(records)}"

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=5001)